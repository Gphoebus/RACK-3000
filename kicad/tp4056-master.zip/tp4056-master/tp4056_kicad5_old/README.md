# tp4056
TP4056 charger kicad schematics

for Kicad 5 version 

TP4056 Lithium Cell Charger Module with Battery Protection  without usb connector
